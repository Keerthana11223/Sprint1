package com.tns.studentProcess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentProcessApplication.class, args);
	}

}
