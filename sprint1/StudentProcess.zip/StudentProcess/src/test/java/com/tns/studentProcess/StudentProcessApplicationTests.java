package com.tns.studentProcess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentProcessApplicationTests {

	@Test
	void contextLoads() {
	}

}
